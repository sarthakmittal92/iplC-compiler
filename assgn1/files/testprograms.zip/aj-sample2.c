int main()
{
    int a,b,temp;
    a=20;
    b=60;
    printf("A = %d and B = %d before swapping\n",a,b);
    temp=a;
    a=b;
    b=temp;
    printf("A = %d and B = %d after swapping\n",a,b);
    return 0;
    
}
