int main()
{
    int a;
    a = 100;

    if (mod(a, 2) == 0) {
        printf("The given number is EVEN");
    }
    else {
        printf("The given number is ODD");
    }
    return 0;
}
