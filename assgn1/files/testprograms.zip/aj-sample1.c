int main()
{
    int a;
    int *p;
    a=10;
    p=&a;
    printf("The ans is %d\n",*p);
    return 0;
}
